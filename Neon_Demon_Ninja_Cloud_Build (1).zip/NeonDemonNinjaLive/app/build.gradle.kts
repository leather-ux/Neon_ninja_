plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.neondemonninja.live"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.neondemonninja.live"
        minSdk = 26
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }
}
