package com.neondemonninja.live

import android.service.wallpaper.WallpaperService
import android.view.SurfaceHolder
import android.view.MotionEvent
import android.graphics.Canvas
import android.graphics.Movie
import android.graphics.Paint
import android.graphics.RectF
import android.content.Context
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.Handler
import android.os.Looper
import android.view.Choreographer
import kotlin.math.min
import kotlin.math.max

class NinjaWallpaperService : WallpaperService() {
    override fun onCreateEngine(): Engine = NinjaEngine()

    inner class NinjaEngine : Engine(), Choreographer.FrameCallback, SensorEventListener {
        private val handler = Handler(Looper.getMainLooper())
        private val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
        private var movie: Movie? = null
        private var visible = false
        private var startedAt = 0L
        private var gyroX = 0f
        private var gyroY = 0f
        private var touchX = 0.5f
        private var touchY = 0.5f
        private var touchPulseUntil = 0L
        private val sensorManager = this@NinjaWallpaperService.getSystemService(Context.SENSOR_SERVICE) as SensorManager
        private val gyro = sensorManager.getDefaultSensor(Sensor.TYPE_GYROSCOPE)

        init {
            assets.open("ninja.gif").use { movie = Movie.decodeStream(it) }
            setTouchEventsEnabled(true)
        }

        override fun onVisibilityChanged(isVisible: Boolean) {
            visible = isVisible
            if (visible) {
                startedAt = System.currentTimeMillis()
                gyro?.let { sensorManager.registerListener(this, it, SensorManager.SENSOR_DELAY_GAME) }
                Choreographer.getInstance().postFrameCallback(this)
            } else {
                Choreographer.getInstance().removeFrameCallback(this)
                sensorManager.unregisterListener(this)
            }
        }

        override fun onSurfaceDestroyed(holder: SurfaceHolder) {
            visible = false
            Choreographer.getInstance().removeFrameCallback(this)
            sensorManager.unregisterListener(this)
            super.onSurfaceDestroyed(holder)
        }

        override fun doFrame(frameTimeNanos: Long) {
            if (!visible) return
            drawFrame()
            Choreographer.getInstance().postFrameCallback(this)
        }

        private fun drawFrame() {
            val holder = surfaceHolder
            var canvas: Canvas? = null
            try {
                canvas = holder.lockCanvas()
                if (canvas != null) {
                    val w = canvas.width.toFloat()
                    val h = canvas.height.toFloat()
                    canvas.drawColor(0xFF05020B.toInt())
                    val m = movie
                    if (m != null) {
                        val duration = max(1, m.duration())
                        val t = ((System.currentTimeMillis() - startedAt) % duration).toInt()
                        m.setTime(t)
                        val scale = max(w / m.width().toFloat(), h / m.height().toFloat())
                        val dw = m.width() * scale
                        val dh = m.height() * scale
                        val parallaxX = gyroX * 18f + (touchX - 0.5f) * pulseStrength()
                        val parallaxY = gyroY * 18f + (touchY - 0.5f) * pulseStrength()
                        val left = (w - dw) / 2f + parallaxX
                        val top = (h - dh) / 2f + parallaxY
                        canvas.save()
                        canvas.drawColor(0xFF05020B.toInt())
                        m.draw(canvas, left, top, paint)
                        canvas.restore()
                        if (System.currentTimeMillis() < touchPulseUntil) {
                            val alpha = ((touchPulseUntil - System.currentTimeMillis()) * 0.55f).toInt().coerceIn(0, 150)
                            val glow = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                                color = (alpha shl 24) or 0x00FF2F8A
                                style = Paint.Style.STROKE
                                strokeWidth = 9f
                            }
                            val radius = (w * 0.08f) + (touchPulseUntil - System.currentTimeMillis()) * 0.25f
                            canvas.drawCircle(touchX * w, touchY * h, radius, glow)
                        }
                    }
                }
            } catch (_: Exception) {
            } finally {
                if (canvas != null) holder.unlockCanvasAndPost(canvas)
            }
        }

        private fun pulseStrength(): Float =
            if (System.currentTimeMillis() < touchPulseUntil) 28f else 0f

        override fun onTouchEvent(event: MotionEvent) {
            if (event.action == MotionEvent.ACTION_DOWN || event.action == MotionEvent.ACTION_MOVE) {
                touchX = (event.x / max(1f, surfaceHolder.surfaceFrame.width().toFloat())).coerceIn(0f, 1f)
                touchY = (event.y / max(1f, surfaceHolder.surfaceFrame.height().toFloat())).coerceIn(0f, 1f)
                touchPulseUntil = System.currentTimeMillis() + 650L
            }
            super.onTouchEvent(event)
        }

        override fun onSensorChanged(event: SensorEvent) {
            if (event.sensor.type == Sensor.TYPE_GYROSCOPE) {
                gyroX = (gyroX * 0.82f + event.values[1] * 0.18f).coerceIn(-1.2f, 1.2f)
                gyroY = (gyroY * 0.82f - event.values[0] * 0.18f).coerceIn(-1.2f, 1.2f)
            }
        }
        override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}
    }
}
